import java.util.Date;
import java.util.Random;


public class GenerateDinamickey {
	//static String appId = "95b5e718c69540669b59fa9906b92748";
    //static String appCertificate = "f30fa591cc5b46f4ae605f738710ed9a";
	
	
    static String appId = "59dff8ec901e4e72950c08df276855e1";
    static String appCertificate = "84318c59c35d4c9896a4e7af9316363d";
    static String channel = "2018092920";
    static int ts = (int)(new Date().getTime()/1000);
    static int r = new Random().nextInt();
    static long uid = 1234567;
   // static int expiredTs = (int)(new Date().getTime()/1000) + 43200;
    static int expiredTs = 0;

    public static void main(String[] args) throws Exception {
    		
        System.out.println(DynamicKey5.generateMediaChannelKey(appId, appCertificate, channel, ts, r, uid, expiredTs));
        System.out.println(new Random().nextInt());
        System.out.println(new Date().getTime()/1000);
		System.out.println(new Date().getTime());
		System.out.println(new Date());
    }
}