package rtm;

import java.util.Date;

import rtm.AccessToken;
import rtm.RtmTokenBuilder;

public class RtmTokenBuilderSample {
    static String appId = "";
    static String appCertificate = "";
    static String channelName = "";
    static String userId = "123456";
 // static int expireTimestamp = (int)(new Date().getTime()/1000) + 2400;
    static int expireTimestamp = 0;

    public static void main(String[] args) throws Exception {
        RtmTokenBuilder token = new RtmTokenBuilder(appId, appCertificate, userId);
        token.setPrivilege(AccessToken.Privileges.kRtmLogin, expireTimestamp);

        String result = token.buildToken();
        System.out.println(result);
    }
}
