package rtm;

import rtm.AccessToken;
import rtm.RtmTokenBuilder;

public class RtmTokenBuilderSample {
    static String appId = "41c9b554f140447abf8ea1dc79ee00f7";
    static String appCertificate = "7a93749e13ee4d159e5dccf54e132fe2";
    static String channelName = "";
    static String userId = "10166";
 // static int expireTimestamp = (int)(new Date().getTime()/1000) + 2400;
    static int expireTimestamp = 0;

    public static void main(String[] args) throws Exception {
        RtmTokenBuilder token = new RtmTokenBuilder(appId, appCertificate, userId);
        token.setPrivilege(AccessToken.Privileges.kRtmLogin, expireTimestamp);

        String result = token.buildToken();
        System.out.println(result);
    }
}
