package io.agora.accesstoken;

import java.util.Date;

import io.agora.accesstoken.AccessToken;
import io.agora.accesstoken.SimpleTokenBuilder;

public class BuilderTokenSample {
	
	static String appId = "41c9b554f140447abf8ea1dc79ee00f7";
    static String appCertificate = "7a93749e13ee4d159e5dccf54e132fe2";
    static String channelName = "354830233ae943e8a4ede1cb3c7d319e"; //频道号
    static String uid = "10166";//32 位无符号整数。建议设置范围：1 到 (2^32-1)，
    //static int expireTimestamp = (int)(new Date().getTime()/1000) + 24*3600;
    static int expireTimestamp = 0; //不设置有效期，则为24小时
    
    public static void main(String[] args) throws Exception {
        SimpleTokenBuilder token = new SimpleTokenBuilder(appId, appCertificate, channelName, uid);
        token.initPrivileges(SimpleTokenBuilder.Role.Role_Publisher);
        token.setPrivilege(AccessToken.Privileges.kJoinChannel, expireTimestamp);
        String result = token.buildToken();
        System.out.println(result);
		System.out.println(new Date());
    }
}
